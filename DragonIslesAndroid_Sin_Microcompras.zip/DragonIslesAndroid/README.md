# Dragon Isles — versión sin microcompras

Prototipo Android WebView del juego Dragon Isles. No contiene tienda de dinero real ni integración de PayPal. Las gemas se obtienen jugando, subiendo de nivel, completando logros y reclamando recompensas diarias.

El progreso se guarda localmente en el dispositivo.
